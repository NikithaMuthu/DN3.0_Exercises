public class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;

    public StripeAdapter() {
        this.stripeGateway = new StripeGateway();
    }

    @Override
    public void processPayment(String paymentMethod, double amount) {
        if (paymentMethod.equals("Stripe")) {
            stripeGateway.chargeCard(amount);
        } else {
            System.out.println("Unsupported payment method");
        }
    }
}