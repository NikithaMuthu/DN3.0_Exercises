public class PaymentProcessorTest {
    public static void main(String[] args) {
        PaymentProcessor paypalAdapter = new PayPalAdapter();
        paypalAdapter.processPayment("PayPal", 100.0);

        PaymentProcessor stripeAdapter = new StripeAdapter();
        stripeAdapter.processPayment("Stripe", 200.0);

        PaymentProcessor bankTransferAdapter = new BankTransferAdapter();
        bankTransferAdapter.processPayment("BankTransfer", 300.0);
    }
}