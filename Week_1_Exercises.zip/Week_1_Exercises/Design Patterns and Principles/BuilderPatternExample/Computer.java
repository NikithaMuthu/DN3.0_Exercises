public class Computer {
    private String cpu;
    private int ram;
    private String storage;
    private boolean hasGraphicsCard;
    private boolean hasSoundCard;

    // Private constructor to prevent direct instantiation
    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.hasGraphicsCard = builder.hasGraphicsCard;
        this.hasSoundCard = builder.hasSoundCard;
    }

    // Getters for attributes
    public String getCpu() {
        return cpu;
    }

    public int getRam() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public boolean hasGraphicsCard() {
        return hasGraphicsCard;
    }

    public boolean hasSoundCard() {
        return hasSoundCard;
    }

    // Static nested Builder class
    public static class Builder {
        private String cpu;
        private int ram;
        private String storage;
        private boolean hasGraphicsCard;
        private boolean hasSoundCard;

        // Constructor to initialize default values
        public Builder() {
            this.cpu = "Intel Core i3";
            this.ram = 8;
            this.storage = "256GB SSD";
            this.hasGraphicsCard = false;
            this.hasSoundCard = false;
        }

        // Methods to set each attribute
        public Builder withCpu(String cpu) {
            this.cpu = cpu;
            return this;
        }

        public Builder withRam(int ram) {
            this.ram = ram;
            return this;
        }

        public Builder withStorage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder withGraphicsCard() {
            this.hasGraphicsCard = true;
            return this;
        }

        public Builder withSoundCard() {
            this.hasSoundCard = true;
            return this;
        }

        // build() method to return an instance of Computer
        public Computer build() {
            return new Computer(this);
        }
    }
}
