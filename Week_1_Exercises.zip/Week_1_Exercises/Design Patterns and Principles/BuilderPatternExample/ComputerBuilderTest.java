// ComputerBuilderTest.java
public class ComputerBuilderTest {
    public static void main(String[] args) {
        // Create a basic computer configuration
        Computer basicComputer = new Computer.Builder()
                .withCpu("Intel Core i5")
                .withRam(16)
                .build();

        System.out.println("Basic Computer:");
        System.out.println("CPU: " + basicComputer.getCpu());
        System.out.println("RAM: " + basicComputer.getRam() + "GB");
        System.out.println("Storage: " + basicComputer.getStorage());

        // Create a gaming computer configuration
        Computer gamingComputer = new Computer.Builder()
                .withCpu("Intel Core i9")
                .withRam(32)
                .withStorage("1TB SSD")
                .withGraphicsCard()
                .withSoundCard()
                .build();

        System.out.println("\nGaming Computer:");
        System.out.println("CPU: " + gamingComputer.getCpu());
        System.out.println("RAM: " + gamingComputer.getRam() + "GB");
        System.out.println("Storage: " + gamingComputer.getStorage());
        System.out.println("Graphics Card: " + (gamingComputer.hasGraphicsCard() ? "Yes" : "No"));
        System.out.println("Sound Card: " + (gamingComputer.hasSoundCard() ? "Yes" : "No"));
    }
}