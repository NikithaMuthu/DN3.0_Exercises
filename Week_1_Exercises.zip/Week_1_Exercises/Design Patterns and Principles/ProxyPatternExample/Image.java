package exercise6;

public interface Image {
    void display();
}
